// Gera um número aleatório entre 1 e 100
let numero = Math.floor(Math.random() * 100) + 1;

// Verifica se o número é maior ou menor que 50
let resultado = numero > 50 ? "Sucesso" : "Falha";

// Exibe o número e o resultado
console.log(`Número gerado: ${numero}`);
console.log(`Resultado: ${resultado}`);
``
