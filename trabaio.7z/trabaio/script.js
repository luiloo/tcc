document.addEventListener('DOMContentLoaded', () => {
    const storyText = document.getElementById('story-text');
    const choicesContainer = document.getElementById('choices-container');
    const vidasContainer = document.getElementById('vidas-container');
    const nextButton = document.getElementById('next-button');

    // Definir a narrativa e opções
    const story = [
        {
            text: 'Você é um cidadão de Oarton, uma vila localizada no reino de Fahrul. Você trabalha como coveiro na cidade. Após um longo dia de trabalho, você volta para casa e, ao chegar lá, vê uma carta com o selo oficial da cidade fechando-a. Quando você abre ela, percebe que se trata de um chamado da própria rainha Rosomon, convocando-o para o castelo dela.',
            choices: [
                // opção 0
                { text: 'Explorar Oarton', next: 2 },
                { text: 'Explorar a floresta', next: 1 },
            ]
        },
        {
            text: 'Ao tentar sair da cidade, os guardas te barram no portão, dizendo que você não pode sair sem equipamentos, pois depois do início da Guerra do Caos, ficou muito perigoso andar por aí desprotegido. Você é obrigado a dar a volta. ',
            choices: [
                // opção 1
                { text: 'Explorar Oarton', next: 2 },
                 ]
        },
        {
            text: 'Voce decide ir visitar o ferreiro para conseguir novos equipamentos antes de ir se encontrar com a rainha',
            choices: [
                // opção 2
                { text: 'Visitar o ferreiro da cidade', next: 3 },
                ]
        },
        
        {
            text: 'Você decide ir visitar o ferreiro para conseguir novos equipamentos. Lá voce encontra Cleber, o ferreiro. Ele te apresenta o arsenal dele.',
            choices: [
                // opção 3
                { text: 'Comprar espada e escudo (18 moedas)', next: 4 },
                { text: 'Comprar machado (13 moedas)', next: 4 }
            ]
        },
        {
            text: 'Após comprar seu equipamento, você decide ir visitar a rainha Rosomon.',
            choices: [
                // opção 4
                { text: 'Visitar a rainha no castelo', next: 5 },
                ]
        },
        {
            text: 'Você decide visitar a rainha no castelo para responder ao chamado dela. Quando voce chega, encontra com outros cidadãos que também foram chamados por ela. Ela aparece à vocês, muito triste com a morte de seu companheiro. Ela fala que o mago real desapareceu, e que o rei Bronner foi morto. Após isso, o reino de Fahrul mergulhou em caos. Ela manda vocês irem até a cidade vizinha de Torralenha para se encontrarem com Hildebrant, um fabricante de bebidas e ex-oficial do exército real. Ele passará mais informações sobre a busca pelo assassino do rei, pelo mago desaparecido e sobre a guerra contra o caos.  ',
            choices: [
                // opção 5
                { text: 'Sair do castelo', next: 6 }
            ]
        },
        {
            text: 'Após sair do castelo, você se vê com duas opções: visitar o ferreiro ou visitar o mercado. O que você faz?',
            choices: [
                // opção 6
                { text: 'Visitar o mercado', next: 7 },
                { text: 'Explorar a floresta', next: 8},
                { text: 'Encerrar o jogo', next: null }
            ]
        },
        {
            text: 'Você decide visitar o mercado. Chegando lá, você encontra Eduardo, o mercador da cidade. Ele te oferece os seguintes itens... ',
            choices: [
                // opção 7
                { text: 'Barba divina (10 moedas)', next: 8},
                { text: 'Cachimbo de olmo (25 moedas)', next: 8 },
                { text: 'Capa de Explorador (30 moedas)', next: 8}
            ]
        },
        {
            text: 'Após comprar seus itens no mercado, o que você faz?',
            choices: [
                // opção 8
                { text: 'Explorar a floresta', next: 9 },
                
            ]
        },
        {
            text: 'Você volta ao centro de Oarton. Agora equipado e sabendo dos seus objetivos, você decide ir até a Floresta. Ao chegar no portão da cidade, os guardas te desejam boa sorte, e você parte para sua jornada.',
            choices: [
                // opção 9
                { text: 'Pegar a estrada até Torralenha', next: 10 },
                { text: 'Explorar os arredores', next: 11 }
            ]
        },
        {
            text: 'Você se dirige rapidamente até a cidade vizinha de Torralenha. O que você faz?',
            choices: [
                // opção 10
                { text: 'Explorar a cidade', next: 3 },
                { text: 'Ir embora', next: 5 }
            ]
        },
        {
            text: 'Você resolve explorar os arredores da cidade. Lá você é surpreendido por um grupo de ladrões. Eles pedem seu ouro e te ameaçam.',
            choices: [
                // opção 11
                { text: 'Ficar e lutar contra os ladrões', next: 1 },
                { text: 'Fugir', next: 1 }
            ]
        },
        {
            text: 'Ao explorar a cidade, você se depara com vários mercadores, mas o clima na cidade é de incerteza. Após o início da Guerra do Caos, as pessoas vivem com medo.',
            choices: [
                // opção 12
                { text: 'Ir até os mercadores e ver seus produtos', next: 13 },
                { text: 'Procurar por Hildebrant', next: 14 }
            ]
        },
        {
            text: 'Você se dirige até os mercadores e pede para ver seus produtos. Eles mostram o estoque para você',
            choices: [
                // opção 
                { text: 'Barba Divina (10 moedas)', next: 1 },
                { text: 'Botas de Explorador (25 moedas)', next: 1 }
            ]
        },

    ];



    const JOGADOR = {
        vida: 100,
        armadura: [],
        ataque: 1
    }
    const MONSTRO = {
        vida: 20,
        armadura: [],
        ataque: 1
    }

    let currentStep = 0;
    var entidades = [];

    entidades.push(JOGADOR);

    function showStory(step) {
        storyText.textContent = story[step].text;
        choicesContainer.innerHTML = '';
        vidasContainer.innerHTML = '';
        entidades.forEach(entidade => {
            barra = document.createElement('progress');
            barra.max = 100;
            barra.value = entidade.vida;
            vidasContainer.appendChild(barra);
        })


        story[step].choices.forEach(choice => {
            const button = document.createElement('button');
            button.textContent = choice.text;
            button.classList.add('choice-button');
            button.addEventListener('click', () => {
                if (choice.next !== null) {
                    currentStep = choice.next;
                    showStory(currentStep);
                } else {
                    alert('Obrigado por jogar!');
                    // Opcional: Reiniciar o jogo ou fazer outra ação
                }
            });
            choicesContainer.appendChild(button);
        });
    }

    nextButton.addEventListener('click', () => {
        if (currentStep === null) return;
        currentStep = (currentStep + 1) % story.length; // Navegação cíclica
        showStory(currentStep);
    });

    // Iniciar o jogo
    showStory(currentStep);
});
