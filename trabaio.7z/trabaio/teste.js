class Character {
    constructor(name, hp, attackPower) {
        this.name = name;
        this.hp = hp;
        this.attackPower = attackPower;
    }

    isAlive() {
        return this.hp > 0;
    }

    attack(opponent) {
        if (this.isAlive()) {
            opponent.hp -= this.attackPower;
            return `${this.name} ataca ${opponent.name} e causa ${this.attackPower} de dano!`;
        } else {
            return `${this.name} não pode atacar porque está derrotado!`;
        }
    }
}

const player = new Character("Jogador", 100, 20);
const enemy = new Character("Inimigo", 80, 15);
let currentAttacker = player;
let currentDefender = enemy;

const charactersDiv = document.getElementById("characters");
const battleLog = document.getElementById("battle-log");
const attackButton = document.getElementById("attack-button");

function updateCharactersDisplay() {
    charactersDiv.innerHTML = `
        <p>${player.name} (HP: ${player.hp})</p>
        <p>${enemy.name} (HP: ${enemy.hp})</p>
    `;
}

function logMessage(message) {
    battleLog.innerHTML += `<p>${message}</p>`;
}

attackButton.addEventListener("click", () => {
    const attackMessage = currentAttacker.attack(currentDefender);
    logMessage(attackMessage);
    updateCharactersDisplay();

    if (!currentDefender.isAlive()) {
        logMessage(`${currentDefender.name} foi derrotado!`);
        attackButton.disabled = true;
        return;
    }

    // Troca de turnos
    [currentAttacker, currentDefender] = [currentDefender, currentAttacker];
});

// Inicialização
updateCharactersDisplay();
